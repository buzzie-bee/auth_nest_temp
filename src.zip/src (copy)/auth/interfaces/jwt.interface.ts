export interface JWT {
  accessToken: string;
}
